ESCAPE THE BEAST

story--
You are part of an elite rescue team sent deep into the jungle to investigate
a series of brutal attacks on local villages. The villagers whisper of a BEAST a
relentless predator hunting them one by one, Your mission was to rescue survivors and
eliminate the threat. 
Deeper into the jungle, your team is ambushed. Communication with base is comprimised
Unseen movements in the shadows, piercing screams in the dark , This is no ordinary predator. 
You were sent to hunt. Now, you are hunted,
Survival is your only mission.

LICENSE
Code under GPL 3.0+ 
Media Under CC BY SA

Other Mods and their License's----
(Mod name | Mod License )
newhand  | cc0
Player_api | MIT
sfinv | MIT
creative | MIT
mobs | MIT
default | LGPL 2.1
screwdriver | LGPL 2.1
the_build_spawner | GPL 3.0
mtfoods | GPL 3.0+
cyber_car | WTFPl



