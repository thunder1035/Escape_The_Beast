# cyber car
Minetest-Mod, Just a normal cyber car 
originally car_f1 by AKhilRaghav0
https://raw.githubusercontent.com/AKhilRaghav0/car_f1/

modification by Thunder1035
add diffferent car model and texture named Cyber Car
