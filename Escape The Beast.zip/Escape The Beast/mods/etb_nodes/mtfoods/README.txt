=-=-=-=-=-=-=

   MTfoods

by:philipbenr

=-=-=-=-=-=-=

This is a mod for Minetest that gives the plyer a chance to make some nice foods like chocolate cakes, a MLT, which is a minetest burger, healing medicine, or a simple apple pie.

=-=-=-=-=-=-=

Rename the folder to mtfoods.

=-=-=-=-=-=-=

Code Licence: GPLv3.0+
http://www.gnu.org/copyleft/gpl.html

Textures License: CC-BY-SA

=-=-=-=-=-=-=
