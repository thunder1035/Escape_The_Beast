-- Define the specific area (modify these coordinates)
local specific_area_min = {x = 5, y = 2.5, z = 55}
local specific_area_max = {x = 47.2, y = 1, z = 8}

-- Define HUD images for death and kill cases
local death_hud_image = "death_image.png"
local kill_hud_image = "kill_image.png"


