--node registration--
minetest.register_node("the_build_spawner:black", {
	description = "Concrete_Black",
	tiles = {"assets_concrete_black.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:blue", {
	description = "Concrete_Blue",
	tiles = {"assets_concrete_blue.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:brown", {
	description = "Concrete_brown",
	tiles = {"assets_concrete_brown.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:cyan", {
	description = "Concrete_cyan",
	tiles = {"assets_concrete_cyan.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:green", {
	description = "Green Concrete",
	tiles = {"assets_concrete_green.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:grey", {
	description = "Concrete_grey",
	tiles = {"assets_concrete_smiley.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:lime", {
	description = "Concrete_lime",
	tiles = {"assets_concrete_lime.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:magenta", {
	description = "Concrete_magenta",
	tiles = {"assets_concrete_magenta.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:orange", {
	description = "Concrete_orange",
	tiles = {"assets_concrete_orange.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:pink", {
	description = "Concrete_pink",
	tiles = {"assets_concrete_pink.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:purple", {
	description = "Concrete_purple",
	tiles = {"assets_concrete_purple.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:red", {
	description = "Concrete_Red",
	tiles = {"assets_concrete_red.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:white", {
	description = "Concrete_White",
	tiles = {"assets_concrete_white.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:yellow", {
	description = "Concrete_yellow",
	tiles = {"assets_concrete_yellow.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:dark_grey", {
	description = "Concrete_darkgrey",
	tiles = {"assets_concrete_darkgrey.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})
minetest.register_node("the_build_spawner:dark_blue", {
	description = "Concrete_dark_blue",
	tiles = {"assets_concrete_dark_blue.png"},
	is_ground_content = false,
    groups = {cracky = 3, stone = 1},
})

