local modpath = minetest.get_modpath("the_build_spawner")

-- Load files

dofile(modpath .. "/blocks.lua")
dofile(modpath .. "/builds.lua")
